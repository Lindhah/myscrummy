from django.apps import AppConfig


class LindascrumyConfig(AppConfig):
    name = 'lindascrumy'
