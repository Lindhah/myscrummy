

=============
leendahscrumy
=============

leendahscrumy is a simple django app to conduct web-based polls.
For each question, visitors can choose between a fixed number of answers.

Quick start
--------------

1. Add "leendahscrumy" to your INSTALLED_APPS setting like this:
       INSTALLED_APPS = [
           ...
           'leendahscrumy',
       ]

2. Include the leendahscrumy URLconf in your project urls.py like this:
      
      path('leendahscrumy/', include('leendahscrumy.urls')),
3. Run 'python manage.py migrate' to create the leendahscrumy models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to creat a poll(you'll need the Amin app enabled).

5. Visit http://127.0.0.1:8000/leendahscrumy/ to participate in the poll.